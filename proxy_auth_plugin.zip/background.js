
    chrome.runtime.onInstalled.addListener(() => {
        chrome.proxy.settings.set({
            value: {
                mode: "fixed_servers",
                rules: {
                    singleProxy: {
                        scheme: "http",
                        host: "103.163.25.103",
                        port: 43782
                    },
                    bypassList: []
                }
            },
            scope: "regular"
        }, function() {});

        chrome.webRequest.onAuthRequired.addListener(
            function(details) {
                return {
                    authCredentials: {
                        username: "WEyRduUf",
                        password: "7tMDv4bU"
                    }
                };
            },
            {urls: ["<all_urls>"]},
            ["blocking"]
        );
    });
    